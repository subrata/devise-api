//= require jquery
//= require bootstrap-sprockets
//= require rails-ujs
