class Api::PostsController < Api::ApplicationController

  skip_before_action :authenticate_user!, only: [:index, :show]
  before_action :set_post, only: [:show, :update, :destroy]

  def index
    render json: Post.all 
  end

  def show
    render json: @post
  end

  def create
    p"==========="
    p params
    p post_params
    p current_user
    post = current_user.posts.new(post_params)
    if post.save
      render json: post, status: 201
    else
      render json: post.errors, status: 422
    end
  end

  def update
    if @post.update_attributes(post_params)
      render json: @post
    else
      render json: @post.errors, status: 422
    end
  end

  def destroy
    @post.destroy
  end

  private

  def set_post
    @post = Post.find(params[:id])
  end

  def post_params
    params.require(:post).permit(:title, :url)
  end
end
