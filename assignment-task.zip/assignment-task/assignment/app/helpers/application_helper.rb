module ApplicationHelper
  def error_messages(resource, resource_name = nil)
    resource_name ||= resource.class.model_name.human.downcase
    render partial: '/layouts/error_messages', locals: { resource: resource,
                                                        resource_name: resource_name }
  end
end
