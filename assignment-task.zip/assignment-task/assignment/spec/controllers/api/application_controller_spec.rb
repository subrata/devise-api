require 'rails_helper'

RSpec.describe Api::ApplicationController, type: :controller do

end
