require 'rails_helper'

RSpec.describe Api::SessionsController, type: :controller do

end
