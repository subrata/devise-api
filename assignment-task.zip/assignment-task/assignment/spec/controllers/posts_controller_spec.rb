require 'rails_helper'

RSpec.describe PostsController, type: :controller do
  user = FactoryGirl.create(:user)

  describe "GET #index" do
    it 'returns all posts as @posts' do
      post = FactoryGirl.create(:post, user: user)
      get :index
      expect(assigns(:posts)).to eq([post])
    end

    it "renders the :index view" do
      get :index
      response.should render_template :index
    end
  end

  describe "GET #new" do
    it "assigns a title, url to the new post" do
      get :new
      assigns(:post).title.should eq %w(title)
    end
  end

  describe "POST create" do
    context "with valid attributes" do
      it "creates a new post" do
        expect{
          post :create, post: FactoryGirl.build(:post, user: user)
        }.to change(post,:count).by(1)
      end
      
      it "redirects to the new post" do
        post :create, post: FactoryGirl.build(:post)
        response.should redirect_to post.last
      end
    end
    
    context "with invalid attributes" do
      it "does not save the new post" do
        expect{
          post :create, post: FactoryGirl.build(:invalid_post)
        }.to_not change(post,:count)
      end
      
      it "re-renders the new method" do
        post :create, post: FactoryGirl.build(:invalid_post)
        response.should render_template :new
      end
    end 
  end

  describe 'PUT update' do
    before :each do
      @post = FactoryGirl.create(:post, title: "Lawrence", url: "google.com")
    end
    
    context "valid attributes" do
      it "located the requested @post" do
        put :update, id: @post, post: FactoryGirl.build(:post)
        assigns(:post).should eq(@post)      
      end
    
      it "changes @post's attributes" do
        put :update, id: @post, 
          post: FactoryGirl.build(:post, title: "Larry")
        @post.reload
        @post.title.should eq("Larry")
      end
    
      it "redirects to the updated post" do
        put :update, id: @post, post: FactoryGirl.build(:post)
        response.should redirect_to @post
      end
    end
    
    context "invalid attributes" do
      it "locates the requested @post" do
        put :update, id: @post, post: FactoryGirl.build(:invalid_post)
        assigns(:post).should eq(@post)      
      end
      
      it "does not change @post's attributes" do
        put :update, id: @post, 
          post: FactoryGirl.build(:post, title: "Larry", url: nil)
        @post.reload
        @post.title.should_not eq("Larry")
      end
      
      it "re-renders the edit method" do
        put :update, id: @post, post: FactoryGirl.build(:invalid_post)
        response.should render_template :edit
      end
    end
  end

  describe 'DELETE destroy' do
    before :each do
      @post = FactoryGirl.create(:post)
    end
    
    it "deletes the post" do
      expect{
        delete :destroy, id: @post        
      }.to change(post,:count).by(-1)
    end
      
    it "redirects to posts#index" do
      delete :destroy, id: @post
      response.should redirect_to posts_url
    end
  end
end
