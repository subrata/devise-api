FactoryGirl.define do
  factory :post do
    user
    title 'New Title'
    url 'new Url'
  end
end
